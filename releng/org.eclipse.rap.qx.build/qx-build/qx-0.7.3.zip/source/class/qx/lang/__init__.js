/**
 * A collection of useful utility functions, which work the buildin JavaSript
 * types.
 */
