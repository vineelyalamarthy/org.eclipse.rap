/**
 * The qx.util.fsm package.
 */
