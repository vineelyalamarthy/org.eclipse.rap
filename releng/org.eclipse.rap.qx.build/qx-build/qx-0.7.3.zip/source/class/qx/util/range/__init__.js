/**
 * Some implementations of ranges.
 */
