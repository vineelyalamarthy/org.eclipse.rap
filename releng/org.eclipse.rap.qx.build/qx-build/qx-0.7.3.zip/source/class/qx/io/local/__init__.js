/**
 * The qx.io.local package.
 */
