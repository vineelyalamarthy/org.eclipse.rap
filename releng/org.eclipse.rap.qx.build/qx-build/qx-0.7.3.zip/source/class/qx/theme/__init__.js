/**
 * The qx.theme package contains the Classic and Ext themes and a set of four
 * icon themes. For details regarding the usage of themes
 * please go to: http://qooxdoo.org/documentation/user_manual/theme_support
 */
