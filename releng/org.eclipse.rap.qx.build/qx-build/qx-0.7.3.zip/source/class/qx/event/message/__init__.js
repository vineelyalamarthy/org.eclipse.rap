/**
 * A simple message bus.
 */
