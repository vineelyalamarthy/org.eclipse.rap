/**
 * The qx.core package.
 */
