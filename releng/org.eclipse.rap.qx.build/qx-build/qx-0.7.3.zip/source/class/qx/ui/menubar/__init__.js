/**
 * The qx.ui.menubar package.
 */
