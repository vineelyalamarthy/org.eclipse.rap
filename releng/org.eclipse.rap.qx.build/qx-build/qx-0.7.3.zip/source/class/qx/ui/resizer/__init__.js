/**
 * The qx.ui.resizer package.
 */
