/**
 * The qx.ui.groupbox package.
 */
