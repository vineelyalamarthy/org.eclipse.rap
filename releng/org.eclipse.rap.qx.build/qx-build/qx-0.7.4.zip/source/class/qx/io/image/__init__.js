/**
 * The qx.io.image package.
 */
