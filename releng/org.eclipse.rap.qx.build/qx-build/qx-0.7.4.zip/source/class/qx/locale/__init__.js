/**
 * The qx.locale package.
 */
