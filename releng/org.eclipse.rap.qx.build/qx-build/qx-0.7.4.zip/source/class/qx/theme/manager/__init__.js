/**
 * Managers for the theming support.
 * http://qooxdoo.org/documentation/user_manual/theme_support
 */
