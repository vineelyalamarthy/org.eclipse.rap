/**
 * Core classes of the qooxdoo widget system.
 */
