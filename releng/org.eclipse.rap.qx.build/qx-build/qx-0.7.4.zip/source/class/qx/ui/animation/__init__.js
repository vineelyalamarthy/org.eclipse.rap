/**
 * The qx.ui.animation package.
 */
