/**
 * The qx.ui.embed package.
 */
