/**
 * The qx.ui.splitpane package.
 */
