/**
 * Complex compound widgets.
 */
