/**
 * User interface selection handling.
 */
