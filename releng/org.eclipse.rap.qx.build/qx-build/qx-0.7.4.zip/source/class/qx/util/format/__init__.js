/**
 * The qx.util.format package.
 */
