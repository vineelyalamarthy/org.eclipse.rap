/**
 * Some general purpose managers.
 */
