/**
 * The qx.event.handler package.
 */
