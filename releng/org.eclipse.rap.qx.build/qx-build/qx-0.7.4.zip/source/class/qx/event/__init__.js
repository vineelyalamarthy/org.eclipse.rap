/**
 * The qx.event package.
 */
