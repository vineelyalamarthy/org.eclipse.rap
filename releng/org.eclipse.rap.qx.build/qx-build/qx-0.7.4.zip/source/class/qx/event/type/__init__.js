/**
 * The qx.event.type package.
 */
